// Load Wi-Fi library
#include <WiFi.h>

// Network credentials
const char* ssid = "YOUR_SSID";           // name of the access point
const char* password = "YOUR_PASSWORD";   // password for the access point

// Add-on network port (what it will listen too)
WiFiServer server(80);

// Variable storing the HTTP request
String header;


// Assign output variables to GPIO pins
const int R_PIN = 25;
const int G_PIN = 27;
const int B_PIN = 26;

// state variables for the color channels
int R = 0;
int G = 0;
int B = 0;


// Current time
unsigned long currentTime = millis();
// Previous time
unsigned long previousTime = 0; 
// Define timeout time in milliseconds (example: 2000ms = 2s)
const long timeoutTime = 2000;

void setup() {
  // serial communication (can get the device IP from this)
  Serial.begin(9600);
  // Initialize the output variables as outputs
  pinMode(R_PIN, OUTPUT);
  pinMode(G_PIN, OUTPUT);
  pinMode(B_PIN, OUTPUT);
  // Set outputs to LOW
  analogWrite(R_PIN, 0);
  analogWrite(G_PIN, 0);
  analogWrite(B_PIN, 0);


  // Connect to Wi-Fi network with SSID and password
  Serial.print("Connecting to ");
  Serial.println(ssid);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  // Print local IP address and start web server
  Serial.println("");
  Serial.println("WiFi connected.");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
  server.begin();
}

// set a color instantly
void setColor(int target_R, int target_G, int target_B){
  // update state
  R = target_R;
  G = target_G;
  B = target_B;
  // set signal values
  analogWrite(R_PIN, R);
  analogWrite(G_PIN, G);
  analogWrite(B_PIN, B);
}

// change the color via a fade effect
void fadeColor(int target_R, int target_G, int target_B){

  // set how quickly the color fades
  const int steps = 20;           // resolution of the fade effect
  const int timeDelay = 75;       // delay between steps, calculated by dividing the desired fade time by the number of steps

  int stepR = (target_R - R) / steps;
  int stepG = (target_G - G) / steps;
  int stepB = (target_B - B) / steps;

  for (int i = 0; i <= steps; i++) {
      setColor(R + stepR * i, G + stepG * i, B + stepB * i);
      delay(timeDelay);
  }

  // make sure the last color is the final one
  setColor(target_R, target_G, target_B);
}


void loop(){
  WiFiClient client = server.available();   // Listen for incoming clients

  if (client) {                             // If a new client connects,

    currentTime = millis();
    previousTime = currentTime;
    Serial.println("New Client.");          // print a message out in the serial port
    String currentLine = "";                // make a String to hold incoming data from the client
    while (client.connected() && currentTime - previousTime <= timeoutTime) {  // loop while the client's connected
      currentTime = millis();
      if (client.available()) {             // if there's bytes to read from the client,
        char c = client.read();             // read a byte, then
        Serial.write(c);                    // print it out the serial monitor
        header += c;
        if (c == '\n') {                    // if the byte is a newline character
          // if the current line is blank, you got two newline characters in a row.
          // that's the end of the client HTTP request, so send a response:
          if (currentLine.length() == 0) {
            // HTTP headers always start with a response code (e.g. HTTP/1.1 200 OK)
            // and a content-type so the client knows what's coming, then a blank line:
            client.println("HTTP/1.1 200 OK");
            client.println("Content-type:text/html");
            client.println("Connection: close");
            client.println();
            
            // if command is to set the color
            if (header.indexOf("GET /set") >= 0) {
              setColor(255,255,255);
              // handle color
              if(header.indexOf("GET /set/blue") >=0 ){
                setColor(0, 0, 255);
                Serial.println("Color set to Blue");
              }
              else if(header.indexOf("GET /set/red") >=0){
                setColor(255, 0, 0);
                Serial.println("Color set to red");
              }
              else if(header.indexOf("GET /set/green") >= 0){
                setColor(0, 255, 0);
                Serial.println("Color set to green");
              }
              else if(header.indexOf("GET /set/yellow") >= 0){
                setColor(255, 255, 0);
                Serial.println("Color set to yellow");
              }
              else if(header.indexOf("GET /set/pink") >= 0){
                setColor(255, 0, 255);
                Serial.println("Color set to pink");
              }
              else if(header.indexOf("GET /set/cyan") >= 0){
                setColor(0, 255, 255);
                Serial.println("Color set to cyan");
              }
              else if(header.indexOf("GET /set/on") >= 0){
                setColor(255, 255, 255);
                Serial.println("Color set to ON");
              }
              else if(header.indexOf("GET /set/off") >= 0){
                setColor(0, 0, 0);
                Serial.println("Color set to OFF");
              }
            }
            // if command is to fade color
            else if (header.indexOf("GET /fade") >= 0){
              
              if(header.indexOf("GET /fade/blue") >=0 ){
                fadeColor(0, 0, 255);
                Serial.println("Color fade to Blue");
              }
              else if(header.indexOf("GET /fade/red") >=0){
                fadeColor(255, 0, 0);
                Serial.println("Color fade to red");
              }
              else if(header.indexOf("GET /fade/green") >= 0){
                fadeColor(0, 255, 0);
                Serial.println("Color fade to green");
              }
              else if(header.indexOf("GET /fade/yellow") >= 0){
                fadeColor(255, 255, 0);
                Serial.println("Color fade to yellow");
              }
              else if(header.indexOf("GET /fade/pink") >= 0){
                fadeColor(255, 0, 255);
                Serial.println("Color fade to pink");
              }
              else if(header.indexOf("GET /fade/cyan") >= 0){
                fadeColor(0, 255, 255);
                Serial.println("Color fade to cyan");
              }
              else if(header.indexOf("GET /fade/on") >= 0){
                fadeColor(255, 255, 255);
                Serial.println("Color fade to ON");
              }
              else if(header.indexOf("GET /fade/off") >= 0){
                fadeColor(0, 0, 0);
                Serial.println("Color fade to OFF");
              }
            }

            else{
              Serial.println("Bad URL");
            }

            
            // Display the HTML web page
            client.println("<!DOCTYPE html><html>");
            client.println("<head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
            client.println("<link rel=\"icon\" href=\"data:,\">");
            // CSS to style the on/off buttons 
            // Feel free to change the background-color and font-size attributes to fit your preferences
            client.println("<style>html { font-family: Helvetica; display: inline-block; margin: 0px auto; text-align: center;color: WHITE;}");
            client.println(".button { background-color: #4CAF50; border: none; color: white; padding: 16px 40px;");
            client.println("text-decoration: none; font-size: 30px; margin: 2px; cursor: pointer;}");
            client.println("body{background-image: url(https://acmi-website-media-prod.s3.ap-southeast-2.amazonaws.com/media/images/confused_travolta_original_acmi.original.jpg);}");
            client.println(".button2 {background-color: #555555;}</style></head>");
            
            // Web Page Heading
            client.println("<body><h1>ESP32 Web Server</h1>");
            
              
            
            // The HTTP response ends with another blank line
            client.println();
            // Break out of the while loop
            break;
          } else { // if you got a newline, then clear currentLine
            currentLine = "";
          }
        } else if (c != '\r') {  // if you got anything else but a carriage return character,
          currentLine += c;      // add it to the end of the currentLine
        }
      }
    }
    // Clear the header variable
    header = "";
    // Close the connection
    client.stop();
    Serial.println("Client disconnected.");
    Serial.println("");
  }
}